<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="{{asset('assets\assets/css/bootstrap.min.css') }}">
</head>
<body>

    <div class="bg-dark py3">
        <div class="container">
            <div class="h4 text-white">Edit Note </div>
</div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between py-3">
            <div class="h4">Edit</div>
            <div>
                <a href="{{route('note.index')}}" class="btn btn-primary">Back</a>
               </div>
            </div>
        <form action="{{route('note.update',$note->id)}}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('put')

            <div class="card border-0 shadow-lg">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Note Title</label>
                        {{-- <input type="text" name="title" id="title" placeholder="Enter title of book" class="form-control --}}
                        <textarea  id="editor" name="title"
                        @error('title') is-invalid @enderror value="{{old('title',$note->title)}}">

                        @error('title')
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </textarea>
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Content</label>
                        {{-- <input type="text" name="content" id="content" placeholder="Enter author name" class="form-control --}}
                        <textarea  id="editors" name="content"
                        @error('author') is-invalid @enderror value="{{old('title',$note->content)}}">

                        @error('author')
                        <p class="invalid-feedback">{{$message}}</p>
                        @enderror
                    </textarea>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary my-3">update note</button>
        </form>
    </div>
</body>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<script>
    ClassicEditor
        .create( document.querySelector( '#editors' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
</html>
