<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create</title>
    <link rel="stylesheet" href="{{ asset('assets/assets/css/bootstrap.min.css') }}">
    <style>
        /* Additional custom styles */
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .header {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .create-heading {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .form-container {
            margin-top: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
        }
        .form-container label {
            font-weight: bold;
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-container button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .error-message {
            color: red;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="container">
            <h1 class="create-heading">Create Note</h1>
        </div>
    </div>

    <div class="container">
        <div class="form-container">
            <div class="d-flex justify-content-between py-3">
                <div class="h4">Create New Note</div>
                <div>
                    <a href="{{ route('note.index') }}" class="btn btn-secondary">Back</a>
                </div>
            </div>

            @if ($errors->any())
            <div class="error-message">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

            <form action="{{ route('note.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="mb-3">
                    <label for="title" class="form-label">Note Title</label>
                    {{-- <input type="text" name="title" id="editor" placeholder="Enter note title" class="form-control --}}
                    <textarea  id="editor" name="title"

                    @error('title') is-invalid @enderror value="{{ old('title') }}">
                </textarea>
                    @error('title')
                    <p class="invalid-feedback">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="content" class="form-label">Content</label>
                    {{-- <input type="text" name="content" id="editors" placeholder="Enter content" class="form-control --}}
                    <textarea  id="editors" name="content"
                    @error('content') is-invalid @enderror value="{{ old('content') }}">
                </textarea>
                    @error('content')
                    <p class="invalid-feedback">{{ $message }}</p>
                    @enderror
                </div>
                <div class="mb-3">
                    <label for="tag_id" class="form-label">Tag</label>
                    <select name="tag_id" id="tag_id" class="form-control">
                        @foreach($tag as $tag)
                        <option value="{{ $tag->id }}">{{ $tag->tag_name }}</option>
                        @endforeach
                    </select>
                </div>
                <button class="btn btn-primary">Save Note</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editors' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
</body>
</html>
