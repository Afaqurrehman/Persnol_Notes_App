

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        </h2>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Tags</title>
            <link rel="stylesheet" href="<?php echo e(asset('assets/assets/css/bootstrap.min.css')); ?>">
            <style>
                /* Additional custom styles */
                body {
                    background-color: #f8f9fa;
                    font-family: Arial, sans-serif;
                }
                .header {
                    background-color: #343a40;
                    color: #fff;
                    padding: 20px 0;
                    text-align: center;
                }
                .tag-heading {
                    font-size: 36px;
                    margin-bottom: 20px;
                }
                .add-buttons {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 20px;
                }
                .add-buttons a {
                    margin-right: 10px;
                    text-decoration: none;
                    padding: 8px 15px;
                    background-color: #007bff;
                    color: #fff;
                    border: none;
                    border-radius: 3px;
                    transition: background-color 0.3s ease-in-out;
                }
                .add-buttons a:hover {
                    background-color: #0056b3;
                    text-decoration: none;
                }
                .tag-table {
                    margin-top: 30px;
                }
                .tag-table th {
                    background-color: #f8f9fa;
                    font-weight: bold;
                }
                .alert-message {
                    margin-top: 20px;
                }
                .table-striped tbody tr:nth-of-type(odd) {
                    background-color: #f8f9fa;
                }
                .table-striped tbody tr:hover {
                    background-color: #e2e6ea;
                }
                .custom-link {
                    color: black;
                    text-decoration: none;
                    transition: color 0.3s ease-in-out;
                }
    .custom-link:hover {
        color: #0056b3;
    }
            </style>
        </head>
        <body>

        <div class="header">
            <div class="container">
                <h1 class="tag-heading">Tags</h1>
            </div>
        </div>

        <div class="container">
            <div class="add-buttons">
                <h2>Add New Tags</h2>
                <div>
                    <a href="<?php echo e(route('tag.create')); ?>" class="btn">Add Tag</a>
                    <a href="<?php echo e(route('note.index')); ?>" class="btn">View Notes</a>
                </div>
            </div>

            <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-message">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>

            <div class="card border-0 shadow-lg tag-table">
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($tag->isNotEmpty()): ?>
                            <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('note.getnote', $tag->id)); ?>" class="custom-link"><?php echo e($tag->tag_name); ?></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="1">No records found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        </body>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\Users\AFAQ UR REHMAN\Desktop\Personal Notes App\app\resources\views/main.blade.php ENDPATH**/ ?>