<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/assets/css/bootstrap.min.css')); ?>">
    <style>
        /* Additional custom styles */
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .header {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .note-heading {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        .action-buttons a {
            margin-right: 10px;
        }
        .search-container {
            margin-top: 20px;
            display: flex;
            align-items: center;
        }
        .search-input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px 0 0 5px;
            width: 60%;
            min-width: 200px;
        }
        .search-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
        }
        .search-button:hover {
            background-color: #0056b3;
        }
        .note-table {
            margin-top: 30px;
        }
        .note-table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .alert-message {
            margin-top: 20px;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f8f9fa;
        }
        .table-striped tbody tr:hover {
            background-color: #e2e6ea;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="container">
            <h1 class="note-heading">Notes</h1>
        </div>
    </div>

    <div class="container">
        <div class="action-buttons">
            <h2>Your Notes</h2>
            <div>
                <a href="<?php echo e(route('note.create')); ?>" class="btn btn-primary">Add Note</a>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">Back</a>
            </div>
        </div>

        <div class="search-container">
            <form action="<?php echo e(route('note.index')); ?>" method="GET" class="form-inline">
                <input type="text" name="search" class="form-control search-input" placeholder="Search Notes">
                <button type="submit" class="mt-3 btn btn-primary search-button">Search</button>
            </form>
        </div>

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-message">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>

        <div class="card border-0 shadow-lg note-table">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Note Title</th>
                            <th>Content</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($note->isNotEmpty()): ?>
                        <?php $__currentLoopData = $note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo $note->title; ?></td>
                            <td><?php echo $note->content; ?></td>
                            <td>
                                <a href="<?php echo e(route('note.edit', $note->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                            </td>
                            <td>
                                <a href="/delete/note/<?php echo e($note->id); ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4">No records found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\AFAQ UR REHMAN\Desktop\Personal Notes App\app\resources\views/note/index.blade.php ENDPATH**/ ?>