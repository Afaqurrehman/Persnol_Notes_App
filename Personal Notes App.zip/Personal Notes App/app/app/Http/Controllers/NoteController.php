<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\NoteController;
use App\Models\Note;
use App\Models\Tag;

class NoteController extends Controller
{
    public function index(Request $request){

    //     $note = Note::orderBy('id','DESC')->get();
    //    return view('note.index',['note'=> $note]);

    $search = $request->input('search');

    $note = Note::when($search, function ($query, $search) {
        return $query->where('title', 'like', "%$search%")
                     ->orWhere('content', 'like', "%$search%");
    })->get();

    return view('note.index', compact('note'));
    }

    public function create(){
        $tag_id = Tag::all();
        return view('note.create',['tag'=>$tag_id]);
    }

    public function store(Request $request){

        $note = new Note();
        $note->title = request("title");
        $note->content =  request("content");
        $note->tag_id =  request("tag_id");
        $note->save();

        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('note.index');



    }
    public function edit($id){
        $note = Note::findOrFail($id);
        return view('note.edit',['note'=>$note]);
    }

    public function update($id, Request $request){
        $note = Note::find($id);
        $note->title = request("title");
        $note->content =  request("content");
        $note->save();

        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('note.index',$note->id);

    }

    public function destroy($id, Request $request){
      $note = Note::find($id);
      $note->delete();

      return redirect()->route('note.index');

    }
    public function getnote($tag_id){
      $getnote = Note::where('tag_id',$tag_id)->get();
        return view('note.getnote',['note'=>$getnote]);
    }
}
