<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Tag;

class TagController extends Controller
{
    public function create(){
        return view('tag.create');
    }

    public function store(Request $request){

        $tag = new Tag();
        $tag->tag_name = request("tag_name");
        $tag->save();

        $request->session()->flash('success','Employee added successfully');

        return redirect()->route('dashboard');



    }
}
