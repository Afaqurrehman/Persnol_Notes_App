<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TagController;
use App\Models\Tag;
use App\Http\Controllers\NoteController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    $tag = Tag::orderBy('id','DESC')->get();
    return view('main',['tag'=> $tag]);
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';


Route::get('/dashboard/create',[TagController::class,'create'])->name('tag.create');

Route::post('/dashboard',[TagController::class,'store'])->name('tag.store');




//now these routes are for notes

Route::get('/note',[NoteController::class,'index'])->name('note.index');

Route::get('/note/create',[NoteController::class,'create'])->name('note.create');

Route::post('/note',[NoteController::class,'store'])->name('note.store');

Route::get('/note/{note}/edit',[NoteController::class,'edit'])->name('note.edit');

Route::put('/note/{note}',[NoteController::class,'update'])->name('note.update');

Route::get('/delete/note/{id}',[NoteController::class,'destroy'])->name('note.destroy');

Route::get('/getnote/{id}',[NoteController::class,'getnote'])->name('note.getnote');
